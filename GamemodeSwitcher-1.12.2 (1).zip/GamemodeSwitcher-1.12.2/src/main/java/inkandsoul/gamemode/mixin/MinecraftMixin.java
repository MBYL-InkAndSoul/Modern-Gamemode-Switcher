package inkandsoul.gamemode.mixin;

import inkandsoul.gamemode.GamemodeSwitcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import static inkandsoul.gamemode.GamemodeSwitcher.showGamemodeSwitcher;

@Mixin(Minecraft.class)
@SideOnly(Side.CLIENT)
public class MinecraftMixin {

    @Inject(method = "Lnet/minecraft/client/Minecraft;processKeyF3(I)Z", at =
        @At("HEAD"), cancellable = true)
    public void f3Addition(int auxKey, CallbackInfoReturnable<Boolean> ci) {
//        ModLogger.LOGGER.info("ModeSwitcher Mixin Start");
        Minecraft mc = (Minecraft) (Object) this;

        if (auxKey == 62 && !showGamemodeSwitcher) {
            mc.displayGuiScreen(new GamemodeSwitcher());
            showGamemodeSwitcher = true;
            ci.setReturnValue(true);
        }
    }

    @Inject(method = "Lnet/minecraft/client/Minecraft;processKeyF3(I)Z", at =
            @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/Minecraft;debugFeedbackTranslated(Ljava/lang/String;[Ljava/lang/Object;)V")
            , locals = LocalCapture.CAPTURE_FAILHARD)
    public void debugKeysAddition(CallbackInfoReturnable<Boolean> ci, GuiNewChat guinewchat) {
        guinewchat.printChatMessage(new TextComponentTranslation("debug.mode_switch.help"));
    }
}
