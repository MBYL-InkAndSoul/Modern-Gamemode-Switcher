package inkandsoul.gamemode;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLLoadEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.spongepowered.asm.mixin.Mixins;

@Mod(modid = ModInfo.MOD_ID, name = ModInfo.MOD_NAME)
public class ModInit {
    @Mod.EventHandler
    public static void preInit(FMLPreInitializationEvent event){
        ModLogger.LOGGER = event.getModLog();
        ModLogger.LOGGER.info("{} is loaded!", ModInfo.MOD_NAME);
    }

}
