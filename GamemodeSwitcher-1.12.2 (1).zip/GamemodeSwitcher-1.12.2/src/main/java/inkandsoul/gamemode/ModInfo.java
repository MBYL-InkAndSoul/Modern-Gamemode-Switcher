package inkandsoul.gamemode;

public class ModInfo {
    public static final String MOD_ID = "gamemode";
    public static final String MOD_NAME = "Gamemode Switcher";
}
