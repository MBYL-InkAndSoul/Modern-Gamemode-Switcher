package inkandsoul.gamemode;

import org.apache.logging.log4j.Logger;

public class ModLogger {
    public static Logger LOGGER;
}
