package inkandsoul.gamemode;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class GamemodeSwitcher extends GuiScreen {
    public static final ResourceLocation TEXTURES =
            new ResourceLocation(ModInfo.MOD_ID, "textures/gui/gamemode_switcher.png");
    public static final ResourceLocation OVERLAY =
            new ResourceLocation(ModInfo.MOD_ID, "textures/gui/overlay.png");

    public static boolean keyDown = false;
    public static boolean lock = false;
    public static boolean showGamemodeSwitcher = false;
    public static int gameMode = 0;

    public GamemodeSwitcher() {

    }

    /** Starting X position for the Gui. Inconsistent use for Gui backgrounds. */
    protected int guiLeft;
    /** Starting Y position for the Gui. Inconsistent use for Gui backgrounds. */
    protected int guiTop;

    private static final int xSize = 250;
    private static final int ySize = 150;

    private static final int[] pos = {20, 60, 80,178};

    @Override
    public void initGui() {
        super.initGui();
        this.guiLeft = (this.width - xSize) >> 1;
        this.guiTop = (this.height - ySize) >> 1;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_FOG);
        this.mc.getTextureManager().bindTexture(TEXTURES);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        int k = guiLeft;
        int l = guiTop;
        this.drawTexturedModalRect(k, l, 0, 0, xSize, ySize);

        String str;
        switch (gameMode) {
            case 0 :
                str = I18n.format("gameMode.survival");
                break;
            case 1 :
                str = I18n.format("gameMode.creative");
                break;
            case 2 :
                str = I18n.format("gameMode.adventure");
                break;
            case 3:
                str = I18n.format("gameMode.spectator");
                break;
            default :
                str = I18n.format("gameMode.unknown");
                break;
        }
        int len = fontRenderer.getStringWidth(str) >> 1;
        fontRenderer.drawString(I18n.format(str), (this.width >> 1) - len, l+20, 0xffffff);

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

        for(int i = 0; i < 4; i++){
            this.mc.getTextureManager().bindTexture(TEXTURES);
            this.drawTexturedModalRect(k+pos[i], l+60, 0, ySize, 52, 52);
        }

        this.mc.getTextureManager().bindTexture(TEXTURES);
        this.drawTexturedModalRect(k+pos[gameMode], l+60, 52, ySize, 52, 52);

//        I don't know why it doesn't work on once foreach.
        for (int i = 0; i < 4; i++) {
            this.mc.getTextureManager().bindTexture(OVERLAY);
            this.drawTexturedModalRect(k+pos[i], l+60, 0, i*52, 52, 52);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        if (keyCode == 62 && !keyDown) {
            if(gameMode < 3){
                gameMode++;
            }else{
                gameMode = 0;
            }
        }
    }

    @Override
    public void updateScreen() {
        if(!Keyboard.isKeyDown(61)){
            mc.displayGuiScreen(null);
            showGamemodeSwitcher = false;
            mc.player.sendChatMessage("/gamemode "+gameMode);
//            mc.thePlayer.sendChatMessage("/gamemode "+gameMode);
//            mc.thePlayer.getCommandSenderName()
        }
    }
}
