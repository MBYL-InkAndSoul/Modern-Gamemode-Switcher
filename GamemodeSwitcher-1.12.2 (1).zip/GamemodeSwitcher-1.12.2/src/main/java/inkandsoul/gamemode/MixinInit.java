package inkandsoul.gamemode;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.spongepowered.asm.mixin.Mixins;
import zone.rong.mixinbooter.IEarlyMixinLoader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
//import zone.rong.mixinbooter.MixinLoader;

//@MixinLoader
@IFMLLoadingPlugin.Name("GamemodeSwitcherMixin")
public class MixinInit implements IEarlyMixinLoader {
    public static final String[] MIXINS = {
            "mixins.gamemode.json"
    };
    @Override
    public List<String> getMixinConfigs() {
        return Arrays.asList(MIXINS);
    }
}
