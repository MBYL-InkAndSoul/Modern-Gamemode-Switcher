package inkandsoul.gamemode.mixin;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import inkandsoul.gamemode.GameModeSwitcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import static inkandsoul.gamemode.GameModeSwitcher.*;


@Mixin(Minecraft.class)
@SideOnly(Side.CLIENT)
public class MinecraftMixin {
    @Inject(method = "runTick()V", at =
    @At(value = "INVOKE", target = "Lnet/minecraft/client/settings/KeyBinding;isPressed()Z", ordinal = 0)
    )
    public void tickAddition(CallbackInfo ci) {
        Minecraft mc = (Minecraft) (Object) this;

        if(mc.currentScreen == null) {
            if (!showGamemodeSwitcher && Keyboard.getEventKey() == 62 && Keyboard.isKeyDown(61)) {
                if (mc.gameSettings.showDebugInfo) {
                    mc.gameSettings.showDebugInfo = false;
                }
                mc.displayGuiScreen(new GameModeSwitcher());
                showGamemodeSwitcher = true;
            }

//            if(showGamemodeSwitcher && !Keyboard.isKeyDown(61)){
//                mc.displayGuiScreen(null);
//                showGamemodeSwitcher = false;
//            }
        }

    }
}
