package inkandsoul.gamemode;

import inkandsoul.gamemode.Tags;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ModLogger {
    public static final Logger LOG = LogManager.getLogger(Tags.MODID);
}
