package inkandsoul.gamemode;

public class ModClientInit {

    public static void preInit(){

    }
    public static void init(){

    }
}
