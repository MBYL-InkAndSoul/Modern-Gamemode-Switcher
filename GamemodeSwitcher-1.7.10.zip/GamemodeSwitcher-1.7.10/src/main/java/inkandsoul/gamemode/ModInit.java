package inkandsoul.gamemode;

import inkandsoul.gamemode.Tags;

public class ModInit {

//    public static final Item item = new BaseItem();
    public static void preInit(){
//        item.setUnlocalizedName("test");
//        item.setTextureName("modid:test");
//        item.setCreativeTab(CreativeTabs.tabMisc);
//
//        GameRegistry.registerItem(item, "test");
        ModLogger.LOG.info("{} is load!", Tags.MODNAME);
    }

    public static void init(){

    }

}
